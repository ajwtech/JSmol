$_L(["java.lang.VirtualMachineError"],"java.lang.UnknownError",null,function(){
c$=$_T(java.lang,"UnknownError",VirtualMachineError);
});
