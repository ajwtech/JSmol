Clazz.declarePackage ("java.util.zip");
Clazz.load (["com.jcraft.jzlib.DeflaterOutputStream"], "java.util.zip.DeflaterOutputStream", null, function () {
c$ = Clazz.declareType (java.util.zip, "DeflaterOutputStream", com.jcraft.jzlib.DeflaterOutputStream);
});
