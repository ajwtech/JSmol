Clazz.declarePackage ("JSV.api");
Clazz.load (["javajs.awt.GenericMenuInterface"], "JSV.api.JSVPopupMenu", null, function () {
Clazz.declareInterface (JSV.api, "JSVPopupMenu", javajs.awt.GenericMenuInterface);
});
