Clazz.declarePackage ("JSV.exception");
Clazz.load (["JSV.exception.JSpecViewException"], "JSV.exception.ScalesIncompatibleException", null, function () {
c$ = Clazz.declareType (JSV.exception, "ScalesIncompatibleException", JSV.exception.JSpecViewException);
});
