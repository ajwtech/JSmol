Clazz.declarePackage ("JZ");
c$ = Clazz.declareType (JZ, "GZIPOutputStream");
