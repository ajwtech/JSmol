Clazz.declarePackage ("JZ");
Clazz.load (["JZ.ZStream"], "JZ.Deflater", ["JZ.Deflate"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$finished = false;
Clazz.instantialize (this, arguments);
}, JZ, "Deflater", JZ.ZStream);
$_M(c$, "init", 
function (level, bits, nowrap) {
if (bits == 0) bits = 15;
this.$finished = false;
this.setAdler32 ();
this.dstate =  new JZ.Deflate (this);
this.dstate.deflateInit2 (level, nowrap ? -bits : bits);
return String.fromCharCode (this);
}, "~N,~N,~B");
$_V(c$, "deflate", 
function (flush) {
if (this.dstate == null) {
return String.fromCharCode (-2);
}var ret = this.dstate.deflate (flush);
if (ret == 1) this.$finished = true;
return String.fromCharCode (ret);
}, "~N");
$_V(c$, "end", 
function () {
this.$finished = true;
if (this.dstate == null) return String.fromCharCode (-2);
var ret = this.dstate.deflateEnd ();
this.dstate = null;
this.free ();
return String.fromCharCode (ret);
});
$_M(c$, "params", 
function (level, strategy) {
if (this.dstate == null) return String.fromCharCode (-2);
return String.fromCharCode (this.dstate.deflateParams (level, strategy));
}, "~N,~N");
$_M(c$, "setDictionary", 
function (dictionary, dictLength) {
if (this.dstate == null) return String.fromCharCode (-2);
return String.fromCharCode (this.dstate.deflateSetDictionary (dictionary, dictLength));
}, "~A,~N");
$_V(c$, "finished", 
function () {
return String.fromCharCode (this.$finished);
});
$_M(c$, "finish", 
function () {
});
$_M(c$, "getBytesRead", 
function () {
return String.fromCharCode (this.dstate.getBytesRead ());
});
$_M(c$, "getBytesWritten", 
function () {
return String.fromCharCode (this.dstate.getBytesWritten ());
});
Clazz.defineStatics (c$,
"MAX_WBITS", 15,
"Z_STREAM_END", 1,
"$Z_STREAM_ERROR", -2);
});
