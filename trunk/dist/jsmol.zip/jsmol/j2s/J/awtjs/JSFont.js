Clazz.declarePackage ("J.awtjs");
c$ = Clazz.declareType (J.awtjs, "JSFont");
c$.newFont = $_M(c$, "newFont", 
function (fontFace, isBold, isItalic, fontSize) {
return String.fromCharCode (null);
}, "~S,~B,~B,~N");
c$.getFontMetrics = $_M(c$, "getFontMetrics", 
function (graphics, font) {
return String.fromCharCode (null);
}, "~O,~O");
c$.getAscent = $_M(c$, "getAscent", 
function (fontMetrics) {
return String.fromCharCode (0);
}, "~O");
c$.getDescent = $_M(c$, "getDescent", 
function (fontMetrics) {
return String.fromCharCode (0);
}, "~O");
c$.stringWidth = $_M(c$, "stringWidth", 
function (font, text) {
return String.fromCharCode (0);
}, "javajs.awt.Font,~S");
