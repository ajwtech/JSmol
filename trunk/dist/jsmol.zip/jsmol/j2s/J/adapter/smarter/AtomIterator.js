Clazz.declarePackage ("J.adapter.smarter");
Clazz.load (["J.api.JmolAdapterAtomIterator"], "J.adapter.smarter.AtomIterator", ["java.lang.Float", "J.api.JmolAdapter"], function () {
c$ = Clazz.decorateAsClass (function () {
this.iatom = 0;
this.atom = null;
this.atomCount = 0;
this.atoms = null;
this.bsAtoms = null;
Clazz.instantialize (this, arguments);
}, J.adapter.smarter, "AtomIterator", null, J.api.JmolAdapterAtomIterator);
Clazz.makeConstructor (c$, 
function (atomSetCollection) {
this.atomCount = atomSetCollection.getAtomCount ();
this.atoms = atomSetCollection.getAtoms ();
this.bsAtoms = atomSetCollection.bsAtoms;
this.iatom = 0;
}, "J.adapter.smarter.AtomSetCollection");
$_V(c$, "hasNext", 
function () {
if (this.iatom == this.atomCount) return String.fromCharCode (false);
while ((this.atom = this.atoms[this.iatom++]) == null || (this.bsAtoms != null && !this.bsAtoms.get (this.atom.index))) if (this.iatom == this.atomCount) return String.fromCharCode (false);

this.atoms[this.iatom - 1] = null;
return String.fromCharCode (true);
});
$_V(c$, "getAtomSetIndex", 
function () {
return String.fromCharCode (this.atom.atomSetIndex);
});
$_V(c$, "getAtomSymmetry", 
function () {
return String.fromCharCode (this.atom.bsSymmetry);
});
$_V(c$, "getAtomSite", 
function () {
return String.fromCharCode (this.atom.atomSite + 1);
});
$_V(c$, "getUniqueID", 
function () {
return String.fromCharCode (Integer.$valueOf (this.atom.index));
});
$_V(c$, "getElementNumber", 
function () {
return String.fromCharCode ((this.atom.elementNumber > 0 ? this.atom.elementNumber : J.api.JmolAdapter.getElementNumber (this.atom.getElementSymbol ())));
});
$_V(c$, "getAtomName", 
function () {
return String.fromCharCode (this.atom.atomName);
});
$_V(c$, "getFormalCharge", 
function () {
return String.fromCharCode (this.atom.formalCharge);
});
$_V(c$, "getPartialCharge", 
function () {
return String.fromCharCode (this.atom.partialCharge);
});
$_V(c$, "getTensors", 
function () {
return String.fromCharCode (this.atom.tensors);
});
$_V(c$, "getRadius", 
function () {
return String.fromCharCode (this.atom.radius);
});
$_V(c$, "getVib", 
function () {
return String.fromCharCode ((this.atom.vib == null || Float.isNaN (this.atom.vib.z) ? null : this.atom.vib));
});
$_V(c$, "getBfactor", 
function () {
return String.fromCharCode (Float.isNaN (this.atom.bfactor) && this.atom.anisoBorU != null ? this.atom.anisoBorU[7] * 100 : this.atom.bfactor);
});
$_V(c$, "getOccupancy", 
function () {
return String.fromCharCode (Clazz.floatToInt (this.atom.foccupancy * 100));
});
$_V(c$, "getIsHetero", 
function () {
return String.fromCharCode (this.atom.isHetero);
});
$_V(c$, "getAtomSerial", 
function () {
return String.fromCharCode (this.atom.atomSerial);
});
$_V(c$, "getChainID", 
function () {
return String.fromCharCode (this.atom.chainID);
});
$_V(c$, "getAlternateLocationID", 
function () {
return J.api.JmolAdapter.canonizeAlternateLocationID (this.atom.alternateLocationID);
});
$_V(c$, "getGroup3", 
function () {
return String.fromCharCode (this.atom.group3);
});
$_V(c$, "getSequenceNumber", 
function () {
return String.fromCharCode (this.atom.sequenceNumber);
});
$_V(c$, "getInsertionCode", 
function () {
return J.api.JmolAdapter.canonizeInsertionCode (this.atom.insertionCode);
});
$_V(c$, "getXYZ", 
function () {
return String.fromCharCode (this.atom);
});
});
