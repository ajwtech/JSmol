Clazz.declarePackage ("J.adapter.smarter");
Clazz.load (["J.api.JmolAdapterStructureIterator"], "J.adapter.smarter.StructureIterator", ["J.api.JmolAdapter"], function () {
c$ = Clazz.decorateAsClass (function () {
this.structureCount = 0;
this.structures = null;
this.structure = null;
this.istructure = 0;
this.bsModelsDefined = null;
Clazz.instantialize (this, arguments);
}, J.adapter.smarter, "StructureIterator", J.api.JmolAdapterStructureIterator);
Clazz.makeConstructor (c$, 
function (atomSetCollection) {
Clazz.superConstructor (this, J.adapter.smarter.StructureIterator, []);
this.structureCount = atomSetCollection.getStructureCount ();
this.structures = atomSetCollection.getStructures ();
this.istructure = 0;
this.bsModelsDefined = atomSetCollection.bsStructuredModels;
}, "J.adapter.smarter.AtomSetCollection");
$_V(c$, "hasNext", 
function () {
if (this.istructure == this.structureCount) return String.fromCharCode (false);
this.structure = this.structures[this.istructure++];
return String.fromCharCode (true);
});
$_V(c$, "getStructureType", 
function () {
return String.fromCharCode (this.structure.structureType);
});
$_V(c$, "getSubstructureType", 
function () {
return String.fromCharCode (this.structure.substructureType);
});
$_V(c$, "getStructureID", 
function () {
return String.fromCharCode (this.structure.structureID);
});
$_V(c$, "getSerialID", 
function () {
return String.fromCharCode (this.structure.serialID);
});
$_V(c$, "getStartChainID", 
function () {
return String.fromCharCode (this.structure.startChainID);
});
$_V(c$, "getStartSequenceNumber", 
function () {
return String.fromCharCode (this.structure.startSequenceNumber);
});
$_V(c$, "getStartInsertionCode", 
function () {
return J.api.JmolAdapter.canonizeInsertionCode (this.structure.startInsertionCode);
});
$_V(c$, "getEndChainID", 
function () {
return String.fromCharCode (this.structure.endChainID);
});
$_V(c$, "getEndSequenceNumber", 
function () {
return String.fromCharCode (this.structure.endSequenceNumber);
});
$_V(c$, "getEndInsertionCode", 
function () {
return this.structure.endInsertionCode;
});
$_V(c$, "getStrandCount", 
function () {
return String.fromCharCode (this.structure.strandCount);
});
$_V(c$, "getStructuredModels", 
function () {
return String.fromCharCode (this.bsModelsDefined);
});
$_V(c$, "getAtomIndices", 
function () {
return String.fromCharCode (this.structure.atomStartEnd);
});
$_V(c$, "getModelIndices", 
function () {
return String.fromCharCode (this.structure.modelStartEnd);
});
});
