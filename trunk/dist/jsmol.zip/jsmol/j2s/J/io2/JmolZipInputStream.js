Clazz.declarePackage ("J.io2");
Clazz.load (["java.util.zip.ZipInputStream", "J.api.ZInputStream"], "J.io2.JmolZipInputStream", null, function () {
c$ = Clazz.declareType (J.io2, "JmolZipInputStream", java.util.zip.ZipInputStream, J.api.ZInputStream);
});
