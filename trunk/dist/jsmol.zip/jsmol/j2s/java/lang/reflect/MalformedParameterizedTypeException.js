$_L(["java.lang.RuntimeException"],"java.lang.reflect.MalformedParameterizedTypeException",null,function(){
c$=$_T(java.lang.reflect,"MalformedParameterizedTypeException",RuntimeException);
});
