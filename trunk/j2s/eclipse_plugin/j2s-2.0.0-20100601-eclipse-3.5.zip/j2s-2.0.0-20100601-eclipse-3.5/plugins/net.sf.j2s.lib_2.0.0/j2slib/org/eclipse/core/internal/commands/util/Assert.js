﻿Clazz.declarePackage ("org.eclipse.core.internal.commands.util");
c$ = Clazz.declareType (org.eclipse.core.internal.commands.util, "Assert");
