﻿Clazz.declarePackage ("org.eclipse.core.internal.content");
c$ = Clazz.declareInterface (org.eclipse.core.internal.content, "ContentTypeVisitor");
Clazz.defineStatics (c$,
"CONTINUE", 0,
"RETURN", 1,
"STOP", 2);
