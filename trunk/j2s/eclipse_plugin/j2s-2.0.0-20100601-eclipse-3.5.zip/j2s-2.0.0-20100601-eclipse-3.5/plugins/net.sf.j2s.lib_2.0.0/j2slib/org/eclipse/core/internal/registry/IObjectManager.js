﻿Clazz.declarePackage ("org.eclipse.core.internal.registry");
Clazz.declareInterface (org.eclipse.core.internal.registry, "IObjectManager");
