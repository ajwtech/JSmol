﻿Clazz.declarePackage ("org.eclipse.core.internal.runtime");
Clazz.load (["java.lang.RuntimeException"], "org.eclipse.core.internal.runtime.AssertionFailedException", null, function () {
c$ = Clazz.declareType (org.eclipse.core.internal.runtime, "AssertionFailedException", RuntimeException);
});
