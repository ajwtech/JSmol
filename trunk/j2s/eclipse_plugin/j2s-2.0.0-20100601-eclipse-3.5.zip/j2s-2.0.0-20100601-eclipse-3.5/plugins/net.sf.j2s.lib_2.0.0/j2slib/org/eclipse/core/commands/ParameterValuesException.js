﻿Clazz.declarePackage ("org.eclipse.core.commands");
Clazz.load (["org.eclipse.core.commands.common.CommandException"], "org.eclipse.core.commands.ParameterValuesException", null, function () {
c$ = Clazz.declareType (org.eclipse.core.commands, "ParameterValuesException", org.eclipse.core.commands.common.CommandException);
});
