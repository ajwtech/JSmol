﻿$_L(["java.lang.RuntimeException"],"java.lang.IndexOutOfBoundsException",null,function(){
c$=$_T(java.lang,"IndexOutOfBoundsException",RuntimeException);
});
