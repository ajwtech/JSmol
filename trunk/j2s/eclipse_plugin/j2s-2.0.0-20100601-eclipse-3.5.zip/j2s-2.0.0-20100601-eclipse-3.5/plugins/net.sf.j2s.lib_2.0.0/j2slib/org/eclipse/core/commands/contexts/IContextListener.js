﻿Clazz.declarePackage ("org.eclipse.core.commands.contexts");
Clazz.declareInterface (org.eclipse.core.commands.contexts, "IContextListener");
