﻿Clazz.declarePackage ("org.eclipse.core.internal.runtime");
c$ = Clazz.declareType (org.eclipse.core.internal.runtime, "Assert");
