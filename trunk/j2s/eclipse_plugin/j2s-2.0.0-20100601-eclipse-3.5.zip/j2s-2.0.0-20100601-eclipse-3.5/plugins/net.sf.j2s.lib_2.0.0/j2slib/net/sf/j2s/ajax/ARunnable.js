﻿$_J("net.sf.j2s.ajax");
c$=$_C(function(){
this.clazz=null;
$_Z(this,arguments);
},net.sf.j2s.ajax,"ARunnable",null,Runnable);
$_M(c$,"getClazz",
function(){
return this.clazz;
});
$_M(c$,"setClazz",
function(clazz){
this.clazz=clazz;
},"Class");
