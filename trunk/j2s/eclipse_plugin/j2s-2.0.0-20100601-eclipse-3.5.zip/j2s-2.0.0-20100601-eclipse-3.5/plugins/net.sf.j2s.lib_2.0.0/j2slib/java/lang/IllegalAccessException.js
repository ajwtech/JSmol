﻿$_L(["java.lang.Exception"],"java.lang.IllegalAccessException",null,function(){
c$=$_T(java.lang,"IllegalAccessException",Exception);
});
