﻿Clazz.declarePackage ("junit.runner");
c$ = Clazz.declareInterface (junit.runner, "TestRunListener");
Clazz.defineStatics (c$,
"STATUS_ERROR", 1,
"STATUS_FAILURE", 2);
