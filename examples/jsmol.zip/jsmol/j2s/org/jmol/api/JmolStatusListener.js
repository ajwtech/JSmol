﻿Clazz.declarePackage ("org.jmol.api");
Clazz.load (["org.jmol.api.JmolCallbackListener"], "org.jmol.api.JmolStatusListener", null, function () {
Clazz.declareInterface (org.jmol.api, "JmolStatusListener", org.jmol.api.JmolCallbackListener);
});
