﻿Clazz.declarePackage ("org.jmol.api");
Clazz.declareInterface (org.jmol.api, "JmolPopupInterface");
