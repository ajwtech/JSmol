﻿Clazz.declarePackage ("org.jmol.api");
c$ = Clazz.declareInterface (org.jmol.api, "JmolGestureServerInterface");
Clazz.defineStatics (c$,
"OK", 1,
"HAS_CLIENT", 2,
"HAS_DRIVER", 4);
