﻿Clazz.declarePackage ("org.jmol.jvxl.api");
Clazz.load (["org.jmol.jvxl.api.VertexDataServer"], "org.jmol.jvxl.api.MeshDataServer", null, function () {
Clazz.declareInterface (org.jmol.jvxl.api, "MeshDataServer", org.jmol.jvxl.api.VertexDataServer);
});
