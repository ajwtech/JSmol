$_L(["java.lang.Error"],"java.lang.LinkageError",null,function(){
c$=$_T(java.lang,"LinkageError",Error);
});
