$_L(["java.io.IOException"],"java.net.MalformedURLException",null,function(){
c$=$_T(java.net,"MalformedURLException",IOException);
});
