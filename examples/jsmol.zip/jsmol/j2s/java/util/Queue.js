﻿$_L(["java.util.Collection"],"java.util.Queue",null,function(){
$_I(java.util,"Queue",java.util.Collection);
});
