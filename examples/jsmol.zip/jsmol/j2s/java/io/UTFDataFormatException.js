﻿$_L(["java.io.IOException"],"java.io.UTFDataFormatException",null,function(){
c$=$_T(java.io,"UTFDataFormatException",java.io.IOException);
});
