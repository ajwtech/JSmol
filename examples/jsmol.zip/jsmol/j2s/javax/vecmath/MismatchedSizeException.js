﻿Clazz.declarePackage ("javax.vecmath");
Clazz.load (["java.lang.RuntimeException"], "javax.vecmath.MismatchedSizeException", null, function () {
c$ = Clazz.declareType (javax.vecmath, "MismatchedSizeException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, javax.vecmath.MismatchedSizeException, []);
});
});
