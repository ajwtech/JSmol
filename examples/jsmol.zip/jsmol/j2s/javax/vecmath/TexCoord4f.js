﻿Clazz.declarePackage ("javax.vecmath");
Clazz.load (["javax.vecmath.Tuple4f"], "javax.vecmath.TexCoord4f", null, function () {
c$ = Clazz.declareType (javax.vecmath, "TexCoord4f", javax.vecmath.Tuple4f, java.io.Serializable);
});
