﻿Clazz.declarePackage ("javax.vecmath");
Clazz.load (["javax.vecmath.Tuple2i"], "javax.vecmath.Point2i", null, function () {
c$ = Clazz.declareType (javax.vecmath, "Point2i", javax.vecmath.Tuple2i, java.io.Serializable);
});
