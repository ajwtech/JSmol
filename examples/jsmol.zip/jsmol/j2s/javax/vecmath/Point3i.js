﻿Clazz.declarePackage ("javax.vecmath");
Clazz.load (["javax.vecmath.Tuple3i"], "javax.vecmath.Point3i", null, function () {
c$ = Clazz.declareType (javax.vecmath, "Point3i", javax.vecmath.Tuple3i, java.io.Serializable);
});
