﻿Clazz.declarePackage ("javax.vecmath");
Clazz.load (["javax.vecmath.Tuple2f"], "javax.vecmath.TexCoord2f", null, function () {
c$ = Clazz.declareType (javax.vecmath, "TexCoord2f", javax.vecmath.Tuple2f, java.io.Serializable);
});
