﻿Clazz.declarePackage ("javax.vecmath");
Clazz.load (["java.lang.RuntimeException"], "javax.vecmath.SingularMatrixException", null, function () {
c$ = Clazz.declareType (javax.vecmath, "SingularMatrixException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, javax.vecmath.SingularMatrixException, []);
});
});
