﻿Clazz.declarePackage ("javax.vecmath");
Clazz.load (["javax.vecmath.Tuple4i"], "javax.vecmath.Point4i", null, function () {
c$ = Clazz.declareType (javax.vecmath, "Point4i", javax.vecmath.Tuple4i, java.io.Serializable);
});
