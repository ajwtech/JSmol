﻿Clazz.declarePackage ("javax.vecmath");
Clazz.load (["javax.vecmath.Tuple3f"], "javax.vecmath.TexCoord3f", null, function () {
c$ = Clazz.declareType (javax.vecmath, "TexCoord3f", javax.vecmath.Tuple3f, java.io.Serializable);
});
