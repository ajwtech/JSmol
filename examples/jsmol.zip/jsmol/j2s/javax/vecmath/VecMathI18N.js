﻿Clazz.declarePackage ("javax.vecmath");
c$ = Clazz.declareType (javax.vecmath, "VecMathI18N");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (key) {
return key;
}, "~S");
