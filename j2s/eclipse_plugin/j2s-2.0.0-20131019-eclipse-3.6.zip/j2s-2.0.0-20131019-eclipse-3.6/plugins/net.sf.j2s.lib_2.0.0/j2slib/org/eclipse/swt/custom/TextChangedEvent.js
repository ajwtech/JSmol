$_L(["$wt.events.TypedEvent"],"$wt.custom.TextChangedEvent",null,function(){
c$=$_T($wt.custom,"TextChangedEvent",$wt.events.TypedEvent);
});
