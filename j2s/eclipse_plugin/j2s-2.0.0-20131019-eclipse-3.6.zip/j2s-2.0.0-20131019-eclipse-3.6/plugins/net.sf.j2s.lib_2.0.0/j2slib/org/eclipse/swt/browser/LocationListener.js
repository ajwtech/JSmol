$_L(["$wt.internal.SWTEventListener"],"$wt.browser.LocationListener",null,function(){
$_I($wt.browser,"LocationListener",$wt.internal.SWTEventListener);
});
