$_L(["$wt.internal.SWTEventListener"],"$wt.events.SelectionListener",null,function(){
$_I($wt.events,"SelectionListener",$wt.internal.SWTEventListener);
});
