$_L(["$wt.events.TypedEvent"],"$wt.events.HelpEvent",null,function(){
c$=$_T($wt.events,"HelpEvent",$wt.events.TypedEvent);
});
