$_L(["java.util.IllegalFormatException"],"java.util.IllegalFormatPrecisionException",null,function(){
c$=$_C(function(){
this.p=0;
$_Z(this,arguments);
},java.util,"IllegalFormatPrecisionException",java.util.IllegalFormatException);
$_K(c$,
function(p){
$_R(this,java.util.IllegalFormatPrecisionException,[]);
this.p=p;
},"~N");
$_M(c$,"getPrecision",
function(){
return this.p;
});
$_V(c$,"getMessage",
function(){
return String.valueOf(this.p);
});
});
