$_L(["$wt.events.TypedEvent"],"$wt.events.FocusEvent",null,function(){
c$=$_T($wt.events,"FocusEvent",$wt.events.TypedEvent);
});
