$_L(["$wt.internal.SWTEventObject"],"$wt.accessibility.AccessibleControlEvent",null,function(){
c$=$_C(function(){
this.childID=0;
this.accessible=null;
this.x=0;
this.y=0;
this.width=0;
this.height=0;
this.detail=0;
this.result=null;
this.children=null;
$_Z(this,arguments);
},$wt.accessibility,"AccessibleControlEvent",$wt.internal.SWTEventObject);
$_V(c$,"toString",
function(){
return"AccessibleControlEvent {childID="+this.childID+" accessible="+this.accessible+" x="+this.x+" y="+this.y+" width="+this.width+" height="+this.height+" detail="+this.detail+" result="+this.result+"}";
});
});
