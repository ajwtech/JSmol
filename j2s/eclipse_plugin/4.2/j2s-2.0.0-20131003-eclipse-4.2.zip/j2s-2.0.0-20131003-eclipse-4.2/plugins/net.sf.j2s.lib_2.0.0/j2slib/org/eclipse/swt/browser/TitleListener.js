$_L(["$wt.internal.SWTEventListener"],"$wt.browser.TitleListener",null,function(){
$_I($wt.browser,"TitleListener",$wt.internal.SWTEventListener);
});
