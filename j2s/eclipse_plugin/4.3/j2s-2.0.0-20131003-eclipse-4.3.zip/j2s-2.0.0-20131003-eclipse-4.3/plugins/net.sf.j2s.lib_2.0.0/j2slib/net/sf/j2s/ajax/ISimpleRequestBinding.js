$_J("net.sf.j2s.ajax");
$_L(["net.sf.j2s.ajax.ISimpleRequestInfoBinding"],"net.sf.j2s.ajax.ISimpleRequestBinding",null,function(){
$_I(net.sf.j2s.ajax,"ISimpleRequestBinding",net.sf.j2s.ajax.ISimpleRequestInfoBinding);
});
