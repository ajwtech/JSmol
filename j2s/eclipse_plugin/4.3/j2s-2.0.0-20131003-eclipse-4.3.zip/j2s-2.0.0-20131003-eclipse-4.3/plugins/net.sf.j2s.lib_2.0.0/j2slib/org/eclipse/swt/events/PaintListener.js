$_L(["$wt.internal.SWTEventListener"],"$wt.events.PaintListener",null,function(){
$_I($wt.events,"PaintListener",$wt.internal.SWTEventListener);
});
