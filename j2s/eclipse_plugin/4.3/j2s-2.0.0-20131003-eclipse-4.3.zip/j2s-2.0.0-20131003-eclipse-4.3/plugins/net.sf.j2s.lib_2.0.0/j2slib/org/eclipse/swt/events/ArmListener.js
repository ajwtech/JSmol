$_L(["$wt.internal.SWTEventListener"],"$wt.events.ArmListener",null,function(){
$_I($wt.events,"ArmListener",$wt.internal.SWTEventListener);
});
