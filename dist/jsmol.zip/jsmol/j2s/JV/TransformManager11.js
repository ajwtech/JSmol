Clazz.declarePackage ("JV");
c$ = Clazz.declareType (JV, "TransformManager11");
