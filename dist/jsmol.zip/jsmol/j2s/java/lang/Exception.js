$_L(["java.lang.Throwable"],"java.lang.Exception",null,function(){
c$=$_T(java.lang,"Exception",Throwable);
});
