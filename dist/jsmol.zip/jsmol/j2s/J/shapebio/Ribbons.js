Clazz.declarePackage ("J.shapebio");
Clazz.load (["J.shapebio.BioShapeCollection"], "J.shapebio.Ribbons", null, function () {
c$ = Clazz.declareType (J.shapebio, "Ribbons", J.shapebio.BioShapeCollection);
});
