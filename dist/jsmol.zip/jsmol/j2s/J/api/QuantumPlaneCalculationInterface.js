Clazz.declarePackage ("J.api");
Clazz.load (["J.api.QuantumCalculationInterface"], "J.api.QuantumPlaneCalculationInterface", null, function () {
Clazz.declareInterface (J.api, "QuantumPlaneCalculationInterface", J.api.QuantumCalculationInterface);
});
