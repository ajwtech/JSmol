Clazz.declarePackage ("J.modelset");
Clazz.declareInterface (J.modelset, "BondIterator");
