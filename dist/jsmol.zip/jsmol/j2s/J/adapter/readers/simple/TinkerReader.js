Clazz.declarePackage ("J.adapter.readers.simple");
Clazz.load (["J.adapter.smarter.AtomSetCollectionReader"], "J.adapter.readers.simple.TinkerReader", ["JU.List", "J.util.Logger"], function () {
c$ = Clazz.declareType (J.adapter.readers.simple, "TinkerReader", J.adapter.smarter.AtomSetCollectionReader);
$_V(c$, "checkLine", 
function () {
var modelAtomCount = this.parseIntStr (this.line);
if (modelAtomCount == -2147483648) {
this.continuing = false;
return false;
}this.atomSetCollection.newAtomSet ();
var name = this.line.substring (this.line.indexOf (" ") + 1);
this.atomSetCollection.setAtomSetName (name);
this.readAtomsAndBonds (modelAtomCount);
this.applySymmetryAndSetTrajectory ();
this.continuing = false;
return false;
});
$_M(c$, "readAtomsAndBonds", 
($fz = function (n) {
var lines =  new JU.List ();
var tokens;
var types = "";
for (var i = 0; i < n; ++i) {
this.readLine ();
tokens = this.getTokens ();
if (tokens.length < 5) {
J.util.Logger.warn ("line cannot be read for atom data: " + this.line);
i--;
continue;
}lines.addLast (tokens);
var atom = this.atomSetCollection.addNewAtom ();
this.setElementAndIsotope (atom, tokens[1]);
atom.x = this.parseFloatStr (tokens[2]);
atom.y = this.parseFloatStr (tokens[3]);
atom.z = this.parseFloatStr (tokens[4]);
types += tokens[5] + "\n";
}
this.atomSetCollection.setAtomSetAtomProperty ("atomType", types, -1);
var temp = "";
for (var i = 0; i < n; i++) {
tokens = lines.get (i);
var index1 = tokens[0];
var i1 = this.parseIntStr (index1) - 1;
for (var j = 6; j < tokens.length; j++) {
var index2 = tokens[j];
var i2 = this.parseIntStr (index2) - 1;
var key = ";" + (i1 < i2 ? index1 : index2) + ";" + (i1 < i2 ? index2 : index1) + ";";
if (temp.indexOf (key) >= 0) continue;
temp += key;
this.atomSetCollection.addNewBondWithOrder (i1, i2, 1);
}
}
}, $fz.isPrivate = true, $fz), "~N");
});
