Clazz.declarePackage ("J.adapter.readers.more");
c$ = Clazz.decorateAsClass (function () {
this.gromacsWideFormat = false;
Clazz.instantialize (this, arguments);
}, J.adapter.readers.more, "PqrReader");
$_M(c$, "initializeReader", 
function () {
isPQR = true;
Clazz.superCall (this, J.adapter.readers.more.PqrReader, "initializeReader", []);
});
