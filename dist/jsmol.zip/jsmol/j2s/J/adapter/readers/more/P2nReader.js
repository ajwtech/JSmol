Clazz.declarePackage ("J.adapter.readers.more");
Clazz.load (["J.util.JmolList"], "J.adapter.readers.more.P2nReader", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.altNames = null;
Clazz.instantialize (this, arguments);
}, J.adapter.readers.more, "P2nReader");
Clazz.prepareFields (c$, function () {
this.altNames =  new J.util.JmolList ();
});
$_M(c$, "setAdditionalAtomParameters", 
function (atom) {
var altName = line.substring ().trim ();
if (altName.length == 0) altName = atom.atomName;
if (useAltNames) atom.atomName = altName;
 else this.altNames.addLast (altName);
}, "J.adapter.smarter.Atom");
$_M(c$, "finalizeReader", 
function () {
finalizeReaderPDB ();
if (!useAltNames) atomSetCollection.setAtomSetAuxiliaryInfo ();
});
});
