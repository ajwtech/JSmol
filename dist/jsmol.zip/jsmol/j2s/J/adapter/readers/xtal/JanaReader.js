Clazz.declarePackage ("J.adapter.readers.xtal");
Clazz.load (["J.adapter.readers.cif.ModulationReader"], "J.adapter.readers.xtal.JanaReader", ["J.io.JmolBinary", "J.util.JmolList", "$.Logger", "$.P3", "$.TextFormat"], function () {
c$ = Clazz.decorateAsClass (function () {
this.m40Data = null;
this.lattvecs = null;
this.tokens = null;
this.qicount = 0;
this.labels = "xyz";
Clazz.instantialize (this, arguments);
}, J.adapter.readers.xtal, "JanaReader", J.adapter.readers.cif.ModulationReader);
Clazz.overrideMethod (c$, "initializeReader", 
function () {
this.setFractionalCoordinates (true);
this.initializeMod ();
this.atomSetCollection.newAtomSet ();
var name = this.filePath;
var pt = name.lastIndexOf (".");
if (pt < 0) return;
name = name.substring (0, pt + 2) + "40";
var id = name.substring (0, pt);
pt = id.lastIndexOf ("/");
id = id.substring (pt + 1);
this.m40Data = this.viewer.getLigandModel (id, name, "_file");
});
Clazz.overrideMethod (c$, "checkLine", 
function () {
if (this.line.length < 3) return true;
J.util.Logger.info (this.line);
this.parseTokenStr (this.line);
switch ("tit  cell ndim qi   lat  sym  spg  end".indexOf (this.line.substring (0, 3))) {
case 0:
this.atomSetCollection.setAtomSetName (this.line.substring (5).trim ());
break;
case 5:
this.cell ();
this.setSymmetryOperator ("x,y,z");
break;
case 10:
this.ndim ();
break;
case 20:
this.lattvec (this.line.substring (8));
break;
case 30:
this.setSpaceGroupName (this.getTokens ()[1]);
break;
case 25:
this.symmetry ();
break;
case 15:
if (!this.modAverage) this.qi ();
break;
case 35:
this.continuing = false;
break;
}
return true;
});
Clazz.overrideMethod (c$, "finalizeReader", 
function () {
this.readM40Data ();
if (this.lattvecs != null) this.atomSetCollection.getSymmetry ().addLatticeVectors (this.lattvecs);
this.applySymmetryAndSetTrajectory ();
this.setModulation ();
this.finalizeReaderASCR ();
});
$_M(c$, "cell", 
($fz = function () {
for (var ipt = 0; ipt < 6; ipt++) this.setUnitCellItem (ipt, this.parseFloat ());

}, $fz.isPrivate = true, $fz));
$_M(c$, "ndim", 
($fz = function () {
this.setModDim (this.line.substring (this.line.length - 1));
}, $fz.isPrivate = true, $fz));
$_M(c$, "qi", 
($fz = function () {
var pt = J.util.P3.new3 (this.parseFloat (), this.parseFloat (), this.parseFloat ());
if (this.qicount == 0) this.addModulation (null, "W_1", pt, -1);
this.addModulation (null, "F_" + (++this.qicount), pt, -1);
}, $fz.isPrivate = true, $fz));
$_M(c$, "lattvec", 
($fz = function (data) {
var a;
var c = data.charAt (0);
switch (c) {
case 'P':
case 'X':
return;
case 'A':
case 'B':
case 'C':
case 'I':
a = [0.5, 0.5, 0.5];
if (c != 'I') a[c.charCodeAt (0) - 65] = 0;
break;
case 'F':
this.lattvec ("A");
this.lattvec ("B");
this.lattvec ("C");
return;
case '0':
if (data.indexOf (".") < 0) return;
a = J.adapter.smarter.AtomSetCollectionReader.getTokensFloat (data, null, this.modDim + 3);
break;
default:
this.appendLoadNote (this.line + " not supported");
return;
}
if (this.lattvecs == null) this.lattvecs =  new J.util.JmolList ();
this.lattvecs.addLast (a);
}, $fz.isPrivate = true, $fz), "~S");
$_M(c$, "symmetry", 
($fz = function () {
this.setSymmetryOperator (J.util.TextFormat.simpleReplace (this.line.substring (9).trim (), " ", ","));
}, $fz.isPrivate = true, $fz));
$_M(c$, "readM40Data", 
($fz = function () {
if (this.m40Data == null) return;
var r = J.io.JmolBinary.getBufferedReaderForString (this.m40Data);
this.readM40Line (r);
var nAtoms = this.parseIntStr (this.tokens[0]);
for (var i = 0; i < nAtoms; i++) {
while (this.readM40Line (r).length == 0 || this.line.charAt (0) == ' ') {
}
var atom = this.atomSetCollection.addNewAtom ();
atom.atomName = this.tokens[0];
this.setAtomCoordXYZ (atom, this.parseFloatStr (this.tokens[4]), this.parseFloatStr (this.tokens[5]), this.parseFloatStr (this.tokens[6]));
var nq = (this.incommensurate && this.tokens.length > 9 ? this.parseIntStr (this.tokens[9]) : 0);
r.readLine ();
for (var j = 0; j < nq; j++) {
var pt;
if (j > 0 && this.getModulationVector ("F_" + (j + 1)) == null) {
pt = J.util.P3.newP (this.getModulationVector ("F_1"));
pt.scale (j + 1);
this.addModulation (null, "F_" + (j + 1), pt, -1);
}this.readM40Line (r);
System.out.println (this.line);
for (var k = 0; k < 3; ++k) {
var ccos = this.parseFloatStr (this.tokens[k]);
var csin = this.parseFloatStr (this.tokens[k + 3]);
if (csin == 0 && ccos == 0) continue;
var axis = "" + "xyz".charAt (k % 3);
if (this.modAxes != null && this.modAxes.indexOf (axis.toUpperCase ()) < 0) continue;
var id = "D_" + (j + 1) + axis + ";" + atom.atomName;
pt = J.util.P3.new3 (csin, ccos, 0);
this.addModulation (null, id, pt, -1);
}
}
}
r.close ();
}, $fz.isPrivate = true, $fz));
$_M(c$, "readM40Line", 
($fz = function (r) {
this.line = r.readLine ();
this.line = J.util.TextFormat.simpleReplace (this.line, "-", " -");
this.tokens = this.getTokens ();
return this.line;
}, $fz.isPrivate = true, $fz), "java.io.BufferedReader");
Clazz.defineStatics (c$,
"records", "tit  cell ndim qi   lat  sym  spg  end",
"TITLE", 0,
"CELL", 5,
"NDIM", 10,
"QI", 15,
"LATT", 20,
"SYM", 25,
"SPG", 30,
"END", 35);
});
