Clazz.declarePackage ("J.adapter.readers.cif");
Clazz.load (["J.adapter.smarter.AtomSetCollectionReader"], "J.adapter.readers.cif.ModulationReader", ["java.util.Hashtable", "J.util.BSUtil", "$.Escape", "$.JmolList", "$.Logger", "$.Matrix3f", "$.Modulation", "$.ModulationSet", "$.P3", "$.SB", "$.TextFormat", "$.V3"], function () {
c$ = Clazz.decorateAsClass (function () {
this.allowRotations = true;
this.modVib = false;
this.modAxes = null;
this.modAverage = false;
this.checkSpecial = true;
this.modDim = 0;
this.incommensurate = false;
this.atoms = null;
this.bsAtoms = null;
this.q1 = null;
this.q1Norm = null;
this.htModulation = null;
this.htAtomMods = null;
this.modT = 0;
this.htSubsystems = null;
this.suffix = null;
this.iopLast = -1;
this.rot = null;
this.f4 = null;
this.epsilon = 0;
this.delta = 0;
Clazz.instantialize (this, arguments);
}, J.adapter.readers.cif, "ModulationReader", J.adapter.smarter.AtomSetCollectionReader);
$_M(c$, "initializeMod", 
function () {
this.modAxes = this.getFilter ("MODAXES=");
this.modVib = this.checkFilterKey ("MODVIB");
this.modAverage = this.checkFilterKey ("MODAVE");
this.checkSpecial = !this.checkFilterKey ("NOSPECIAL");
this.atomSetCollection.setCheckSpecial (this.checkSpecial);
this.allowRotations = !this.checkFilterKey ("NOSYM");
});
$_M(c$, "setModDim", 
function (token) {
this.modDim = this.parseIntStr (token);
if (this.modAverage) return;
if (this.modDim > 1) {
this.appendLoadNote ("Too high modulation dimension (" + this.modDim + ") -- reading average structure");
this.modDim = 0;
this.modAverage = true;
} else {
this.appendLoadNote ("Modulation dimension = " + this.modDim);
this.htModulation =  new java.util.Hashtable ();
}this.incommensurate = (this.modDim > 0);
}, "~S");
$_M(c$, "getModulationVector", 
function (id) {
return this.htModulation.get (id);
}, "~S");
$_M(c$, "addModulation", 
function (map, id, pt, iModel) {
if (map == null) map = this.htModulation;
id += "@" + (iModel >= 0 ? iModel : this.atomSetCollection.getCurrentAtomSetIndex ());
J.util.Logger.info ("Adding " + id + " " + pt);
map.put (id, pt);
}, "java.util.Map,~S,J.util.P3,~N");
$_M(c$, "setModulation", 
function () {
if (!this.incommensurate || this.htModulation == null) return;
this.setModulationForStructure (this.atomSetCollection.getCurrentAtomSetIndex ());
});
$_M(c$, "getMod", 
($fz = function (key) {
return this.htModulation.get (key + this.suffix);
}, $fz.isPrivate = true, $fz), "~S");
$_M(c$, "setModulationForStructure", 
($fz = function (iModel) {
this.suffix = "@" + iModel;
var key;
if (this.htModulation.containsKey ("X_" + this.suffix)) return;
this.htModulation.put ("X_" + this.suffix,  new J.util.P3 ());
this.q1 = this.getMod ("W_1");
if (this.q1 == null) return;
this.q1Norm = J.util.V3.new3 (this.q1.x == 0 ? 0 : 1, this.q1.y == 0 ? 0 : 1, this.q1.z == 0 ? 0 : 1);
var pt;
var n = this.atomSetCollection.getAtomCount ();
var map =  new java.util.Hashtable ();
for (var e, $e = this.htModulation.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
if ((key = this.checkKey (e.getKey ())) == null) continue;
pt = e.getValue ();
switch (key.charAt (0)) {
case 'O':
if (!this.modVib && this.bsAtoms == null) this.bsAtoms = this.atomSetCollection.bsAtoms = J.util.BSUtil.newBitSet2 (0, n);
case 'D':
if (pt.z == 1 && key.charAt (2) != 'S') {
var a = pt.x;
var d = 2 * 3.141592653589793 * pt.y;
pt.x = (a * Math.cos (d));
pt.y = (a * Math.sin (-d));
pt.z = 0;
J.util.Logger.info ("msCIF setting " + key + " " + pt);
}break;
case 'F':
if (key.indexOf ("_q_") >= 0) {
var pf =  new J.util.P3 ();
if (pt.x != 0) pf.scaleAdd2 (pt.x, this.getMod ("W_1"), pf);
if (pt.y != 0) pf.scaleAdd2 (pt.y, this.getMod ("W_2"), pf);
if (pt.z != 0) pf.scaleAdd2 (pt.z, this.getMod ("W_3"), pf);
key = J.util.TextFormat.simpleReplace (key, "_q_", "");
this.addModulation (map, key, pf, iModel);
this.appendLoadNote ("Wave vector " + key + "(n=" + (this.modDim == 1 ? Integer.$valueOf (Clazz.floatToInt (pt.x)) : pt) + ") = " + pf);
} else {
var fn = Clazz.floatToInt (pt.dot (this.q1) / this.q1.dot (this.q1) * 1.01);
var k2 = key + "_q_";
if (!this.htModulation.containsKey (k2 + this.suffix)) {
this.addModulation (map, k2, J.util.P3.new3 (fn, 0, 0), iModel);
this.appendLoadNote ("Wave vector " + key + " = " + pt + " n = " + fn);
}}break;
}
}
if (!map.isEmpty ()) this.htModulation.putAll (map);
var haveAtomMods = false;
for (var e, $e = this.htModulation.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
if ((key = this.checkKey (e.getKey ())) == null) continue;
var params = e.getValue ();
var atomName = key.substring (key.indexOf (";") + 1);
var pt_ = atomName.indexOf ("#=");
if (pt_ >= 0) {
params = this.getMod (atomName.substring (pt_ + 2));
atomName = atomName.substring (0, pt_);
}System.out.println (key + " " + params);
var type = key.charCodeAt (0);
pt_ = key.indexOf ("#") + 1;
var utens = null;
switch (type) {
case 'U':
utens = key.substring (4, key.indexOf (";"));
case 'O':
case 'D':
var id = key.charAt (2);
var axis = key.charAt (pt_);
type = (id == 'S' ? 1 : id == '0' ? 3 : type == 79 ? 2 : type == 85 ? 4 : 0);
if (this.htAtomMods == null) this.htAtomMods =  new java.util.Hashtable ();
var fn = (id == 'S' ? 0 : this.parseIntStr (key.substring (2)));
key = (fn == 0 ? "W_1" : "F_" + fn);
var nq = this.getMod (key);
fn = (fn == 0 ? 1 : Clazz.floatToInt (this.getMod (key + "_q_").x));
var list = this.htAtomMods.get (atomName);
if (list == null) this.htAtomMods.put (atomName, list =  new J.util.JmolList ());
list.addLast ( new J.util.Modulation (nq, axis, type, fn, params, utens));
haveAtomMods = true;
break;
}
}
if (!haveAtomMods) return;
this.atoms = this.atomSetCollection.getAtoms ();
this.symmetry = this.atomSetCollection.getSymmetry ();
this.iopLast = -1;
this.f4 =  Clazz.newFloatArray (4, 0);
var sb =  new J.util.SB ();
for (var i = this.atomSetCollection.getLastAtomSetAtomIndex (); i < n; i++) this.modulateAtom (this.atoms[i], sb);

this.atomSetCollection.setAtomSetAtomProperty ("modt", sb.toString (), -1);
this.htAtomMods = null;
}, $fz.isPrivate = true, $fz), "~N");
$_M(c$, "checkKey", 
($fz = function (key) {
var pt_ = key.indexOf (this.suffix);
return (pt_ < 0 ? null : key.substring (0, pt_));
}, $fz.isPrivate = true, $fz), "~S");
$_M(c$, "modulateAtom", 
function (a, sb) {
var list = this.htAtomMods.get (a.atomName);
if (list == null || this.symmetry == null || a.bsSymmetry == null) return;
var iop = a.bsSymmetry.nextSetBit (0);
if (iop < 0) iop = 0;
var mdim = 0;
if (iop != this.iopLast) {
this.symmetry.getMod456Row (iop, mdim, this.f4);
this.iopLast = iop;
this.rot =  new J.util.Matrix3f ();
this.epsilon = this.f4[0];
this.delta = this.f4[3] - this.modT;
}this.symmetry.getSpaceGroupOperation (iop).getRotationScale (this.rot);
var ms =  new J.util.ModulationSet (a.index + " " + a.atomName, list);
a.vib = ms;
ms.epsilon = this.epsilon;
ms.delta = this.delta;
ms.r = J.util.P3.newP (a);
ms.rot = this.rot;
ms.calculate ();
if (ms.v < 0.5) {
a.occupancy = 0;
if (this.bsAtoms != null) this.bsAtoms.clear (a.index);
}if (ms.htValues != null) {
System.out.println ("U1: " + a.index + " " + a.atomName + " " + a + " " + J.util.Escape.eAF (a.anisoBorU));
for (var e, $e = ms.htValues.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) this.addUStr (a, e.getKey (), e.getValue ().floatValue ());

this.atomSetCollection.addRotatedTensor (a, this.symmetry.getTensor (a.anisoBorU), iop, true);
System.out.println ("U2: " + a.index + " " + a.atomName + " " + a + " " + J.util.Escape.eAF (a.anisoBorU) + "\n");
}if (this.modVib || a.occupancy != 0) {
var t = this.q1Norm.dot (a);
if (Math.abs (t - Clazz.floatToInt (t)) > 0.001) t = Clazz.doubleToInt (Math.floor (t));
sb.append ((Clazz.floatToInt (t)) + "\n");
}if (!this.modVib) {
a.add (ms);
ms.setModT (true, 2147483647);
}this.symmetry.toCartesian (ms, true);
}, "J.adapter.smarter.Atom,J.util.SB");
$_M(c$, "addSubsystem", 
function (code, m4, atomName) {
if (this.htSubsystems == null) this.htSubsystems =  new java.util.Hashtable ();
if (m4 == null) this.htSubsystems.put (";" + atomName, code);
 else this.htSubsystems.put (code, m4);
}, "~S,J.util.Matrix4f,~S");
$_M(c$, "addUStr", 
($fz = function (atom, id, val) {
var i = Clazz.doubleToInt ("U11U22U33U12U13U23OTPUISO".indexOf (id) / 3);
System.out.println ("adding " + id + " " + i + " " + val + " to " + atom.anisoBorU[i]);
this.setU (atom, i, val + atom.anisoBorU[i]);
}, $fz.isPrivate = true, $fz), "J.adapter.smarter.Atom,~S,~N");
$_M(c$, "setU", 
function (atom, i, val) {
var data = this.atomSetCollection.getAnisoBorU (atom);
if (data == null) this.atomSetCollection.setAnisoBorU (atom, data =  Clazz.newFloatArray (8, 0), 8);
data[i] = val;
}, "J.adapter.smarter.Atom,~N,~N");
Clazz.defineStatics (c$,
"U_LIST", "U11U22U33U12U13U23OTPUISO");
});
