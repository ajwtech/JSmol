Clazz.declarePackage ("JSV.exception");
Clazz.load (["JSV.exception.JSpecViewException"], "JSV.exception.JDXSourceException", null, function () {
c$ = Clazz.declareType (JSV.exception, "JDXSourceException", JSV.exception.JSpecViewException);
});
