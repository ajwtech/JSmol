Clazz.declarePackage ("J.consolejs");
Clazz.declareInterface (J.consolejs, "JSConsole");
